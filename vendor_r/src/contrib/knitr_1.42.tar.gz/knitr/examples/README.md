# knitr-examples

To compile the `knitr-graphics` example, look at the bottom of the file
[`knitr-graphics.lyx`](knitr-graphics.lyx) for its dependencies.
