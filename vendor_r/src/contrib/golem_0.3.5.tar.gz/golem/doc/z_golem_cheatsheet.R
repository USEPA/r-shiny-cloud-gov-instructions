## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- echo=FALSE, out.width="100%"--------------------------------------------
knitr::include_graphics("golem_cheatsheet_V0.1.jpg")

