#ifndef TZDB_ISLAMIC_H
#define TZDB_ISLAMIC_H

#include <tzdb/defines.h>
#include <date/islamic.h>

#endif
