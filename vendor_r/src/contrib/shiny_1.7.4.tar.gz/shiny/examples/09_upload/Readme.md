We can add a file upload input in the UI using the function `fileInput()`,
e.g. `fileInput('foo')`. In the `server` function, we can access the 
uploaded files via `input$foo`.
